/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 6, 2019 10:11AM
 * Purpose:  Drink Machine
 *         
 */

//System Libraries
#include <iostream>     //I/O Library -> cout,endl
#include <string>       //String Library
#include <iomanip>      //Format Library

using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
const int SIZE = 5;
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
struct drnk{
    string name;    //Name of drink 
    float cost;     //Cost of drink
    int numDM;      //Number of drinks left in the machine            
};

int main(int argc, char** argv) {
    //set point
    cout<<fixed<<setprecision(2)<<endl;
    //Declare Variables
    string choice;
    float cash,earn;
    drnk dinfo[SIZE];
    dinfo[0]={"Cola",0.75,20};
    dinfo[1]={"Root Beer",0.75,20};
    dinfo[2]={"Lemon-Lime",0.75,20};
    dinfo[3]={"Grape Soda",0.80,20};
    dinfo[4]={"Cream Soda",0.80,20};
    bool quit = false;
    bool real = false;
    earn =  0;
    cout<<"Drink Name - Cost - Number in Machine"<<endl;

    //Loop the code
    do{
        cout<<dinfo[0].name<<"        "<<dinfo[0].cost<<"  "<<dinfo[0].numDM<<endl;
        cout<<dinfo[1].name<<"   "<<dinfo[1].cost<<"  "<<dinfo[1].numDM<<endl;
        for(int i=2;i<SIZE;i++){
           cout<<dinfo[i].name<<"  "<<dinfo[i].cost<<"  "<<dinfo[i].numDM<<endl;
        }
        cout<<"Quit"<<endl;
        getline(cin,choice);
        if(choice=="Cola"){
            do{
                cin>>cash;
                if(cash >= 0.75 ){
                    real=true;
                }
                else{
                    cout<<"Invalid"<<endl;
                }
            }while(!real);
            real = false;
            earn+=0.75;
            dinfo[0].numDM--;
        }
        if(choice=="Root Beer"){
            do{
                cin>>cash;
                if(cash >= 0.75 ){
                    real=true;
                }
                else{
                    cout<<"Invalid"<<endl;
                }
            }while(!real);
            real = false;
            earn+=0.75;
            dinfo[1].numDM--;
        }
        if(choice=="Lemon-Lime"){
            do{
                cin>>cash;
                if(cash >= 0.75 ){
                    real=true;
                }
                else{
                    cout<<"Invalid"<<endl;
                }
            }while(!real);
            real = false;
            earn+=0.75;
            dinfo[2].numDM--;
        }
        if(choice=="Grape Soda"){
            do{
                cin>>cash;
                if(cash >= 0.80 ){
                    real=true;
                }
                else{
                    cout<<"Invalid"<<endl;
                }
            }while(!real);
            real = false;
            earn+=0.80;
            dinfo[3].numDM--;
        }
        if(choice=="Cream Soda"){
            do{
                cin>>cash;
                if(cash >= 0.80 ){
                    real=true;
                }
                else{
                    cout<<"Invalid"<<endl;
                }
            }while(!real);
            real = false;
            earn+=0.80;
            dinfo[4].numDM--;
        }
        if(choice=="Quit"){
            earn+=0.00;
            quit=true;
        }
    }while(!quit);
    cout<<earn<<endl;
    //Output
    //Exit program!
    return 0;
}