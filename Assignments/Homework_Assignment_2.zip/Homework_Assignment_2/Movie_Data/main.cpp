/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 5, 2019 12:45PM
 * Purpose:  Structures Movie Data
 *         
 */

//System Libraries
#include <iostream>     //I/O Library -> cout,endl
#include <string>       //String Library
#include <iomanip>      //Format Library

using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
int const SIZE = 50; //array size
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
struct MvieDta{
    string title[SIZE];                             //Name of the movie
    string dirtor[SIZE];                            //Name of the director
    int myear[SIZE];                                //Yeah release
    int mtime[SIZE];                                //Length of the movie
    int movies;                                     //Number of movies
};

int main(int argc, char** argv) {
    //Declare Variables
    MvieDta tiket; //Movie data variable
    
    //Initial Variables
    
    //Display
    cout<<"This program reviews structures"<<endl;
    cout<<"Input how many movies, "
            "the Title of the Movie, "
            "Director, "
            "Year Released, "
            "and the Running Time in (minutes)."<<endl;
    cin>>tiket.movies;
    for(int i=0;i<tiket.movies;i++){    
        cin.ignore();
        getline(cin, tiket.title[i]);
        getline(cin, tiket.dirtor[i]);
        cin>>tiket.myear[i];
        cin>>tiket.mtime[i];
        if(i<tiket.movies){
            cout<<endl;
        }

        cout<<"Title:     "<<tiket.title[i]<<endl;
        cout<<"Director:  "<<tiket.dirtor[i]<<endl;
        cout<<"Year:      "<<tiket.myear[i]<<endl;
        cout<<"Length:    "<<tiket.mtime[i]<<endl;
            
    }
    //Exit program!
    return 0;
}