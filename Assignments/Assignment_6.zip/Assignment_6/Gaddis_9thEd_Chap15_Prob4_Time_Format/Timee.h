/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Timee.h
 * Author: Andres
 *
 * Created on July 22, 2019, 7:19 PM
 */
using namespace std;
#ifndef TIMEE_H
#define TIMEE_H
#include <iostream>
#include <string>
class Timee{
protected:
    int hour;
    int min;
    int sec;
public:
    //Default constructor
    Timee();
    SetTimee(int,int,int);
    int getMin()const{return min;}
    int getSec()const{return sec;}
    string getAmPm();
    int getHour();
};

#endif /* TIMEE_H */

