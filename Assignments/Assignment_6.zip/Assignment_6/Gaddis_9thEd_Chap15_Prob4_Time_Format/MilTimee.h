/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MilTimee.h
 * Author: Andres
 *
 * Created on July 22, 2019, 7:35 PM
 */
#include <iostream>
#include "Timee.h"
#ifndef MILTIMEE_H
#define MILTIMEE_H

class MilTimee:public Timee{
protected:
    int milHrs;
    int milMins;
    int milSecs;
public:
    MilTimeeS(int,int,int);
    int getmHrs(){return milHrs;}
    int getmMins(){return milMins;}
    int getmSecs(){return milSecs;}
};

#endif /* MILTIMEE_H */

