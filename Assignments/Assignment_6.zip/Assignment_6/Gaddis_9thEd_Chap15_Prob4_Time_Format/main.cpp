/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  CPP Template
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created
#include "MilTimee.h"
#include "Timee.h"
//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int mTime;
    int mSec;
    int hrs,
                 mins;
    int onesdig,//Ones place
                 tensdig,//Tens place
                 hunsdig,//Hundreds place
                  thsdig;//Thousands place
    bool corrT=false;
    bool corrS=false;
    //Map/Process Inputs to Outputs
    do{
        cout<<"What is the time in military format?(00:00, do not input a ':'!)"<<endl;
        cin>>mTime;
        if(mTime >=0 && mTime<=2359){
            corrT=true;
        }
        else{
            cout<<"Incorrect Time! PLEASE TRY AGAIN!"<<endl;
        }
    }while(!corrT);
    
    do{
        cout<<"What is the seconds?(0-59)"<<endl;
        cin>>mSec;
        if(mSec >=0 && mSec<=59){
            corrS=true;
        }
        else{
            cout<<"Incorrect Time! PLEASE TRY AGAIN!"<<endl;
        }
    }while(!corrS);
    thsdig  = mTime /1000;      //1st number of the hours
    hunsdig = mTime /100 % 10;  //2nd number of the hours
    tensdig = mTime / 10 % 10;
    onesdig = mTime % 10;
    if(thsdig == 2){
        hrs=20;
    }
    if (thsdig==1){
        hrs=10;
    }
    if (thsdig==0){
        hrs=0;
    }
    hrs += hunsdig;
    if(tensdig==0){
        mins=0;
    }
    if(tensdig==1){
        mins=10;
    }
    if(tensdig==2){
        mins=20;
    }
    if(tensdig==3){
        mins=30;
    }
    if(tensdig==4){
        mins=40;
    }
    if(tensdig==5){
        mins=50;
    }
    mins += onesdig;
    MilTimee milT;
    milT.MilTimeeS(hrs,mins,mSec);  //Military
    milT.SetTimee(hrs,mins,mSec);   //Standard
    cout<<"Military Time: "<<milT.getmHrs()<<":"<<milT.getmMins()<<":"<<milT.getmSecs()<<endl;
    cout<<"Standard Time: "<<milT.getAmPm()<<" "<<milT.getHour()<<":"<<milT.getMin()<<":"<<milT.getSec()<<" "<<endl;
    //Exit program!
    return 0;
}
