/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "MilTimee.h"
#include "Timee.h"
#include <iostream>
using namespace std;\

MilTimee::MilTimeeS(int mH,int mM,int mS){
    milHrs=mH;
    milMins=mM;
    milSecs=mS;
}
