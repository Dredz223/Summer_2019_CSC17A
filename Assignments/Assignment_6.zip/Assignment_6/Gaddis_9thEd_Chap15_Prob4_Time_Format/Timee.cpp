/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>
#include <string>
#include "Timee.h"

using namespace std;

Timee::Timee(){
    hour=0;
    min=0;
    sec=0;
}
Timee::SetTimee(int h,int m,int s){
    hour=h;
    min=m;
    sec=s;
}
string Timee::getAmPm(){
    if(hour>=0 && hour<=11){return "AM";}
    else if(hour>=12 && hour<=23){return "PM";} 
    hour - 12;
    cout<<hour<<endl;
}
    int Timee::getHour(){
    hour-12;
    return hour;
}