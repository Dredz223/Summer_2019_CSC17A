/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "MilTimee.h"
#include "Timee.h"
#include <iostream>
using namespace std;\

MilTimee::MilTimeeS(int mT,int mS){
    if(mT>=0 && mT<=2359){
        unsigned int thsdig,hunsdig,tensdig,onesdig;
        thsdig  = (mT /1000) * 10;      //1st number of the hours
        hunsdig = mT /100 % 10;         //2nd number of the hours
        tensdig = (mT / 10 % 10)*10;
        onesdig = mT % 10;
        milHrs = (thsdig + hunsdig);
        milMins = (tensdig + onesdig);
    }
    else{
        throw InvalidHr(mT);
    }
    if(mS>=0 && mS<=59){
        milSecs=mS;
    }
    else{
        throw InvalidSec(mS);
    }
}
