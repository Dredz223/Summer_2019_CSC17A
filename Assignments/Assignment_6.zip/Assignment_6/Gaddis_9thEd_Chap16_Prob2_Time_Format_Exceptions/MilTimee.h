/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   MilTimee.h
 * Author: Andres
 *
 * Created on July 22, 2019, 7:35 PM
 */
#include <iostream>
#include "Timee.h"
#ifndef MILTIMEE_H
#define MILTIMEE_H

class MilTimee:public Timee{
protected:
    int milHrs;
    int milMins;
    int milSecs;
public:
    //Exception Class for an invalid hour
    class InvalidHr{
    private:
        int value;
    public:
        InvalidHr(int val){value=val;}
        int getValue() const{return value;}
    };
    //Exception Class for an invalid seconds
    class InvalidSec{
    private:
        int value;
    public:
        InvalidSec(int val){value=val;}
        int getValue() const{return value;}
    };
    MilTimeeS(int,int);
    int getmHrs(){return milHrs;}
    int getmMins(){return milMins;}
    int getmSecs(){return milSecs;}
};

#endif /* MILTIMEE_H */

