/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Date.h
 * Author: Andres
 *
 * Created on July 18, 2019, 8:12 PM
 */
#include <iostream>
#include <string>
using namespace std;
#ifndef DATE_H
#define DATE_H

class Date{
private:
    int day;
    int month;
    int year;
public:
    //Exception Class for an invalid day
    class InvalidDay{
    private:
        int value;
    public:
        InvalidDay(int val){value=val;}
        int getValue() const{return value;}
    };
    //Exception Class for an invalid month
    class InvalidMon{
    private:
        int value;
    public:
        InvalidMon(int val){value=val;}
        int getValue() const{return value;}
    };
    Date(int,int,int);
    int getDay(){return day;}
    string getMonth();
    int getYear(){return year;}
};

#endif /* DATE_H */

