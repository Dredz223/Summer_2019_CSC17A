/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 18, 2019 4:46PM
 * Purpose:  Date Class
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries
#include "Date.h"
//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int day;
    int month;
    int year;
    //Initial Variables
    
    //Map/Process Inputs to Outputs
    cout<<"What is the date(DD)?"<<endl;
    cin>>day;
    cout<<"What is the date(MM)?"<<endl;
    cin>>month;
    cout<<"What is the date(YYYY)?"<<endl;
    cin>>year;
    try{
        Date date(day,month,year);
    cout<<date.getMonth()<<" "<<date.getDay()<<", "<<date.getYear()<<endl;
    cout<<month<<"/"<<date.getDay()<<"/"<<date.getYear()<<endl;
    cout<<date.getDay()<<" "<<date.getMonth()<<" "<<date.getYear()<<endl;
    }
    catch(Date::InvalidDay e){
        cout<<"Error: "<<e.getValue()<<" is an invalid value for the day!"<<endl;
    }
    catch(Date::InvalidMon e){
        cout<<"Error: "<<e.getValue()<<" is an invalid value for the month!"<<endl;
    }
    cout<<"End of program!"<<endl;
    //Exit program!
    return 0;
}