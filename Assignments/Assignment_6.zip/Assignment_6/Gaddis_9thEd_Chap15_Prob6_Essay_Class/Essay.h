/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Essay.h
 * Author: Andres
 *
 * Created on July 23, 2019, 12:41 AM
 */
#include <iostream>
#include "GradedActivity.h"
using namespace std;
#ifndef ESSAY_H
#define ESSAY_H

class Essay:GradedActivity{
    
};

#endif /* ESSAY_H */

