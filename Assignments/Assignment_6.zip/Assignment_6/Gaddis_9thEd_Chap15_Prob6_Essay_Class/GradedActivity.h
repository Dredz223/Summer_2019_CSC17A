/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   GradedActivity.h
 * Author: Andres
 *
 * Created on July 22, 2019, 11:53 PM
 */
#include <iostream>
using namespace std;
#ifndef GRADEDACTIVITY_H
#define GRADEDACTIVITY_H

class GradedActivity{
protected:
    char letter;            //Hold letter Grade
    float score;            //Hold numeric score
    void determineGrade();  //Determines letter grade
public:
    //Default constructor
    GradedActivity();
    //Mutator
    void setScore(float);
    //Accessor
    float getScore()const{return score;}
    char getLetterGrade()const{return letter;}
};

#endif /* GRADEDACTIVITY_H */

