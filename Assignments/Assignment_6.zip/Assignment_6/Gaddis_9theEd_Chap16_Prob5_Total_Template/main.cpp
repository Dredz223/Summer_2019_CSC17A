/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  CPP Template
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
template <class T1,class T2>
int toTal(T1 num,T2 val){
    T1 tot;
    for(int i=1;i<=val;i++){
        tot+=num;
    }
        return tot;
}
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int val;
    int numT;
    float numF;
    char choice;
    //Map/Process Inputs to Outputs
    cout<<"How many values are you inputting?"<<endl;
    cin>>val;
    cout<<"Floats or integers(F/I)?"<<endl;
    cin>>choice;
    
    switch(choice){
        case 'F':
            for(int i=1; i<=val;i++){    
            cout<<"Please enter a float!"<<endl;
            cin>>numF;
            toTal(numF,val);
            }
            cout<<"Total: "<<toTal(numF,val)<<endl;
            break;
        case 'I':
            for(int i=1; i<=val;i++){    
            cout<<"Please enter an Integer!"<<endl;
            cin>>numT;
            toTal(numT,val);
            }
            cout<<"Total: "<<toTal(numT,val)<<endl;
            break;
    }
    
    cout<<"End of program!"<<endl;
    //Exit program!
    return 0;
}