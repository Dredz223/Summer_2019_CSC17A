/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  CPP Template
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
template <class T>
T absVal(T num){
    if(num<0){
        T neg=-1;
        return (num*neg);
    }
    else if(num >0){
        return num;
    }
}
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int numT;
    float numF;
    //Map/Process Inputs to Outputs
    cout<<"Please enter an integer!"<<endl;
    cin>>numT;
    cout<<"Please enter a float!"<<endl;
    cin>>numF;
    cout<<"The absolute value of the integer "<<numT<<" is "<<absVal(numT)<<endl;
    cout<<"The absolute value of the float "<<numF<<" is "<<absVal(numF)<<endl;
    cout<<"End of program!"<<endl;
    //Exit program!
    return 0;
}