/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  Min/Max Templates
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
template <class T1,class T2>
T1 minimum(T1 num1,T2 num2){
    if (num1<num2)return num1;
    else if(num2<num1)return num2;
}
template <class T1,class T2>
T2 maximum(T1 num1,T2 num2){
    if (num1>num2)return num1;
    else if(num2>num1)return num2;
}
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int num1in,num2in;
    float num1f, num2f;
    //Map/Process Inputs to Outputs
    cout<<"Enter 2 integers"<<endl;
    cin>>num1in>>num2in;
    cout<<"Enter 2 floats"<<endl;
    cin>>num1f>>num2f;
    
    cout<<"Mini (int): "<<minimum(num1in,num2in)<<endl;
    cout<<"Max (int): "<<maximum(num1in,num2in)<<endl;
    cout<<"Mini (float): "<<minimum(num1f,num2f)<<endl;
    cout<<"Max (float): "<<maximum(num1f,num2f)<<endl;
    cout<<"End of program."<<endl;
    //Exit program!
    return 0;
}
