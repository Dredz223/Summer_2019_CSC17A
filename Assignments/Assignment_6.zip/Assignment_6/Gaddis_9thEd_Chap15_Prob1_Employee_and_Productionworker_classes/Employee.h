/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Employee.h
 * Author: Andres
 *
 * Created on July 22, 2019, 9:54 AM
 */
#include <iostream>
#include <string>
#ifndef EMPLOYEE_H
#define EMPLOYEE_H
using namespace std;

class Employee{
private:
    string name;
    int num;
    string date;
public:
    Employee();
    void sayHi();
    SetEmployee(string,int,string);
    string getName(){return name;}
    int getNum(){return num;}
    string getDate(){return date;}
};


#endif /* EMPLOYEE_H */

