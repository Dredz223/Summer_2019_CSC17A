/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Employee.h"
#include "ProductionWorker.h"
using namespace std;


Employee::Employee(){
    name=" ";
    num=0;
    date=" ";
}
void Employee::sayHi(){
    cout<<"Hello!"<<endl;
}
Employee::SetEmployee(string n, int nm,string d){
    name = n;
    num = nm;
    date = d;
    cout<<"Data Set!"<<endl;
}
