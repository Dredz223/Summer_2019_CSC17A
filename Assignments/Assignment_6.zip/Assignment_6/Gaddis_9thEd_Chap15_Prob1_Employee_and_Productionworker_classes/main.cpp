/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on September 18, 2018 7:58PM
 * Purpose:  CPP Template
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library

#include "Employee.h"  
#include "ProductionWorker.h"
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    Employee emp;
    ProductionWorker wrk;
    string name;
    int num;
    string date;
    int shf;
    float pay;
    cout<<setprecision(2)<<fixed;
    cout<<"What is your name?"<<endl;
    getline(cin,name);
    cout<<"What is your employee number?"<<endl;
    cin>>num;
    cout<<"What was the date you were hired?(MM/DD/YYYY)"<<endl;
    cin>>date;
    emp.SetEmployee(name,num,date);
    cout<<"What is your shift day(1) or night(2)? (Please enter 1 or 2)"<<endl;
    cin>>shf;
    cout<<"What is your pay rate?"<<endl;
    cin>>pay;
    wrk.SetWrkr(shf,pay);
    //Map/Process Inputs to Outputs
    cout<<"Worker Name: "<<emp.getName()<<endl;
    cout<<"Worker Number: "<<emp.getNum()<<endl;
    cout<<"Date hired: "<<emp.getDate()<<endl;
    cout<<"Shift: "<<wrk.getShift()<<endl;
    cout<<"Pay Rate: $"<<wrk.getPayR()<<endl;
    wrk.sayHi();
    //Exit program!
    return 0;
}
