/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ProductionWorker.h
 * Author: Andres
 *
 * Created on July 22, 2019, 10:33 AM
 */
#include "Employee.h"
#ifndef PRODUCTIONWORKER_H
#define PRODUCTIONWORKER_H
using namespace std;

class ProductionWorker: public Employee{
private:
    int shift;
    float payR;
public:
    ProductionWoker();
    SetWrkr(int,float);
    getShift(){return shift;}
    getPayR(){return payR;}
};

#endif /* PRODUCTIONWORKER_H */

