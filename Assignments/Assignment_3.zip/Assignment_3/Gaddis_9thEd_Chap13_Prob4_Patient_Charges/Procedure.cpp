/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Procedure.h"
using namespace std;

Procedure::Procedure(string n, string d, string p, float c){
    procn=n;
    procd=d;
    prcti=p;
    proch=c;
}