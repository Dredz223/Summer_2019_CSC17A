/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Patient.h"
using namespace std;

Patient::Patient(string f,string m,string las,string add,string c,
                 string s,string z,string ph,string en,string eph){
    nameF = f;
    nameM = m;
    nameL = las;
    addss = add; 
    city = c;
    state = s;
    zip = z;
    phonum = ph;   //Phone Number
    ename = en; //Emergency number
    ephonum = eph;  //Emergency number
}
