/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Patient.h
 * Author: Andres
 *
 * Created on July 19, 2019, 1:38 PM
 */
#include <string>
using namespace std;
#ifndef PATIENT_H
#define PATIENT_H
class Patient{
private:
    string nameF;
    string nameM;
    string nameL;
    string addss; //getline()
    string city;
    string state;
    string zip;
    string phonum;   //Phone Number
    string ename; //Emergency number
    string ephonum;  //Emergency number
public:
    Patient(string,string,string,string,string,string,string,string,string,string);
    string getNameF(){return nameF;}
    string getNameM(){return nameM;}
    string getNameL(){return nameL;}
    string getaddss(){return addss;}
    string getcity(){return city;}
    string getstate(){return state;}
    string getzip(){return zip;}
    string getnum(){return phonum;}
    string getename(){return ename;}
    string getenum(){return ephonum;}
};

#endif /* PATIENT_H */

