/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 18, 2019 4:46PM
 * Purpose:  Date Class
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
#include "Patient.h"
#include "Procedure.h"
using namespace std;//namespace I/O stream library created

//User Libraries
//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    cout<<setprecision(2)<<fixed;
    string nameF;
    string nameM;
    string nameL;
    string addss; 
    string city;
    string state;
    string zip;
    string phonum;   //Phone Number
    string ename; //Emergency number
    string ephonum;  //Emergency number
    string procn;   //Name of procedure
    string procd;   //Date of procedure
    string prcti;   //Practitioner
    float  proch;   //Procedure charge
    //Initial Variables
    cout<<"What is your first name?"<<endl;
    cin>>nameF;
    cout<<"What is your middle name?"<<endl;
    cin>>nameM;
    cout<<"What is your last name?"<<endl;
    cin>>nameL;
    cin.ignore();
    cout<<"What is your address?"<<endl;
    getline(cin,addss);
    cout<<"What is your city?"<<endl;
    cin>>city;
    cout<<"What is your state?"<<endl;
    cin>>state;
    cout<<"What is your zip code?"<<endl;
    cin>>zip;
    cout<<"What is your phone number(no spaces or dashes)?"<<endl;
    cin>>phonum;
    cout<<"Who is your emergency contact name?"<<endl;
    cin.ignore();
    getline(cin,ename);
    cout<<"What is your emergency contact's phone number(no spaces or dashes)?"<<endl;
    cin>>ephonum;
    cout<<"What is the name of the procedure?"<<endl;
    cin.ignore();
    getline(cin,procn);
    cout<<"What is the day of the procedure?(MM/DD/YYYY)"<<endl;
    cin>>procd;
    cout<<"Who is the practitioner?"<<endl;
    cin.ignore();
    getline(cin,prcti);
    cout<<"how much did the practitioner charge?"<<endl;
    cin>>proch;
    
    //Class variable
    Patient patt(nameF,nameM,nameL,addss,city,state,zip,phonum,ename,ephonum);
    Procedure pro(procn,procd,prcti,proch);
    //Map/Process Inputs to Outputs
    cout<<"Patient Info"<<endl;
    cout<<"====================================================================="<<endl;
    cout<<"Name: "<<patt.getNameF()<<" "<<patt.getNameM()<<" "<<patt.getNameL()<<endl;
    cout<<"Address: "<<patt.getaddss()<<" City: "<<patt.getcity()<<" State: "<<patt.getstate()<<endl;
    cout<<"ZIP: "<<patt.getzip()<<" Number:"<<patt.getnum()<<endl;
    cout<<"Emergency Contact's info: Name:"<<patt.getename()<<" Number: "<<patt.getenum()<<endl;
    cout<<"====================================================================="<<endl;
    cout<<"Procedure #1"<<endl;
    cout<<"====================================================================="<<endl;
    cout<<"Procedure Name: "<<pro.getProcn()<<endl;
    cout<<"Date: "<<pro.getProcd()<<endl;
    cout<<"Practitioner: "<<pro.getPrcti()<<endl;
    cout<<"Charge: "<<pro.getProch()<<endl;
    cout<<"====================================================================="<<endl;

    //Exit program!
    return 0;
}