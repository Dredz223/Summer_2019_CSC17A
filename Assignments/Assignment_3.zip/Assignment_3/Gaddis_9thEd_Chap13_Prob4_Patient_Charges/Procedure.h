/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Procedure.h
 * Author: Andres
 *
 * Created on July 19, 2019, 5:12 PM
 */
#include <string>
using namespace std;
#ifndef PROCEDURE_H
#define PROCEDURE_H
class Procedure{
private:
    string procn;   //Name of procedure
    string procd;   //Date of procedure
    string prcti;   //Practitioner
    float  proch;   //Procedure charge
public:
    Procedure(string,string,string,float);
    string getProcn(){return procn;}
    string getProcd(){return procd;}
    string getPrcti(){return prcti;}
    float getProch(){return proch;}
};


#endif /* PROCEDURE_H */

