/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Retailitem.h"

using namespace std;

Retailitem::Retailitem(string d,int u,float p){
    desc=d;
    units=u;
    price=p;
}