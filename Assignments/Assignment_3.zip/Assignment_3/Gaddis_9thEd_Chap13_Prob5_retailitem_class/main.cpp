/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 19, 2019 6:53PM
 * Purpose:  Retain item Class
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created
#include "Retailitem.h"
//User Libraries
//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    cout<<fixed<<setprecision(2);
    //Initial Variables
    string desc;
    int   units;
    float price;
    //Ask user
    cout<<"What is the description of item#1?"<<endl;
    getline(cin,desc);
    cout<<"What is the amount of item#1 we have?"<<endl;
    cin>>units;
    cout<<"What is the cost of item#1?"<<endl;
    cin>>price;
    //Map/Process Inputs to Outputs
    Retailitem item1(desc,units,price);
    cout<<"What is the description of item#2?"<<endl;
    cin.ignore();
    getline(cin,desc);
    cout<<"What is the amount of item#2 we have?"<<endl;
    cin>>units;
    cout<<"What is the cost of item#2?"<<endl;
    cin>>price;
    Retailitem item2(desc,units,price);
    cout<<"What is the description of item#3?"<<endl;
    cin.ignore();
    getline(cin,desc);
    cout<<"What is the amount of item#3 we have?"<<endl;
    cin>>units;
    cout<<"What is the cost of item#3?"<<endl;
    cin>>price;
    Retailitem item3(desc,units,price);
    cout<<"--------------------------------------------------------------------"<<endl;
    cout<<"         Description              Units on Hand                Price"<<endl;
    cout<<"Item #1  "<<item1.getDescp()<<"                        "<<item1.getUnits()<<"                           $ "<<item1.getPrice()<<endl;
    cout<<"Item #2  "<<item2.getDescp()<<"                        "<<item2.getUnits()<<"                           $ "<<item2.getPrice()<<endl;
    cout<<"Item #3  "<<item3.getDescp()<<"                        "<<item3.getUnits()<<"                           $ "<<item3.getPrice()<<endl;
    //Exit program!
    return 0;
}