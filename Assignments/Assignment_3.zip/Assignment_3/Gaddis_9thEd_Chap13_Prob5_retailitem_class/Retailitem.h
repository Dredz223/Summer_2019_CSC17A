/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   RetailItem.h
 * Author: Andres
 *
 * Created on July 19, 2019, 6:56 PM
 */
#include <string>
#ifndef RETAILITEM_H
#define RETAILITEM_H
using namespace std;

class Retailitem{
private:
    string desc;
    int units;
    float price;
public:
    Retailitem(string,int,float);
    string getDescp(){return desc;}
    int getUnits(){return units;}
    float getPrice(){return price;}
};

#endif /* RETAILITEM_H */

