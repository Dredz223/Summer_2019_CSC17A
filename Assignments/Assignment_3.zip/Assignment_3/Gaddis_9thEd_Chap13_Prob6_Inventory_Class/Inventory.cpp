/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include "Inventory.h"
using namespace std;



Inventory::InvenZero(){
    itmnum=0;  
    quant=0;  
    cost=0; 
    totcost=0;
}
Inventory::InvenGain(int it, int qu, float c,float tc){
    itmnum=it;
    quant=qu;  
    cost=c; 
    totcost=quant*cost;
}