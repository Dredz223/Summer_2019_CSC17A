/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Inventory.h
 * Author: Andres
 *
 * Created on July 19, 2019, 9:42 PM
 */
using namespace std;
#ifndef INVENTORY_H
#define INVENTORY_H

class Inventory{
private:
    int itmnum;  //Item number
    int quant;   //Quantity
    float cost;  //Cost   
    float totcost;//Total Cost
public:
    InvenZero();
    InvenGain(int,int,float,float);
    int getItemnum(){return itmnum;}
    int getQuanity(){return quant;}
    int getCost(){return cost;}
    int gettotCost(){return totcost;}
};   

#endif /* INVENTORY_H */

