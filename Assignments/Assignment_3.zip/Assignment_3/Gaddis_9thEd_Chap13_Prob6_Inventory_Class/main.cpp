/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 19, 2019 9:40PM
 * Purpose:  Inventory Class
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
#include "Inventory.h"
using namespace std;//namespace I/O stream library created
//User Libraries
//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    cout<<fixed<<setprecision(2);
    //Initial Variables
    int itmnum;
    int quant;
    float cost;
    bool num=false;
    bool quan=false;
    bool cst=false;
    do{
        cout<<"What is the item number? (max 5 digits)"<<endl;
        cin>>itmnum;
        if(itmnum>=0){
            num=true;
        }
        else{
            cout<<"Incorrect input!"<<endl;
        }
    }while(!num);
    do{
        cout<<"What is the quantity of the item?"<<endl;
        cin>>quant;
        if(quant>=0){
            quan=true;
        }
        else{
            cout<<"Incorrect input!"<<endl;
        }
    }while(!quan);
    do{
        cout<<"What is the cost of the item?"<<endl;
        cin>>cost;
        if(cost>=0){
            cst=true;
        }
        else{
            cout<<"Incorrect input!"<<endl;
        }
    }while(!cst);

    Inventory inv;
    cout<<"Item number: "<<inv.getItemnum()<<endl;
    cout<<"Item quantity: "<<inv.getQuanity()<<endl;
    cout<<"Item cost: "<<inv.getCost()<<endl;
    cout<<"Total cost of item: "<<inv.gettotCost()<<endl;
    
    //Exit program!
    return 0;
}