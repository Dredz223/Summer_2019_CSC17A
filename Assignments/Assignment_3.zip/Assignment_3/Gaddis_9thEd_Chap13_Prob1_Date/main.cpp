/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 18, 2019 4:46PM
 * Purpose:  Date Class
 *         
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>   //String Library
#include <iomanip>  //Format Library
using namespace std;//namespace I/O stream library created

//User Libraries
#include "Date.h"
//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int day;
    int month;
    int year;
    bool corrd = false;
    bool corrm = false;
    //Initial Variables
    
    //Map/Process Inputs to Outputs
    do{
        cout<<"What is the date(DD)?"<<endl;
        cin>>day;
        if(day >=1 && day<=31) corrd = true;
        else{cout<<"Invalid Day, try again."<<endl;}
    }while(!corrd);
    do{
        cout<<"What is the date(MM)?"<<endl;
        cin>>month;
        if(month >=1 && month<=12) corrm = true;
        else{cout<<"Invalid Day, try again."<<endl;}
    }while(!corrm);
    cout<<"What is the date(YYYY)?"<<endl;
    cin>>year;
    Date date(day,month,year);
    cout<<date.getMonth()<<" "<<date.getDay()<<", "<<date.getYear()<<endl;
    cout<<month<<"/"<<date.getDay()<<"/"<<date.getYear()<<endl;
    cout<<date.getDay()<<" "<<date.getMonth()<<" "<<date.getYear()<<endl;
    
    //Exit program!
    return 0;
}