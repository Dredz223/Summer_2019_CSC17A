/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Date.h
 * Author: Andres
 *
 * Created on July 18, 2019, 8:12 PM
 */
#include <string>
using namespace std;
#ifndef DATE_H
#define DATE_H

class Date{
private:
    int day;
    int month;
    int year;
public:
    Date(int,int,int);
    int getDay(){return day;}
    string getMonth();
    int getYear(){return year;}
};

#endif /* DATE_H */

