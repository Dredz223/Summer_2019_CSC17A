/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 12th, 2019, 6:40 PM
 * Purpose:  Menu using Functions,
 *           extend for midterm
 */

//System Libraries
#include <iostream>
#include <cstring>
#include <iomanip>
using namespace std;

//User Libraries
struct employee{
    string name,    //Name
           comp,    //Company
           addss;   //Address
    int hours;      //Work Hours
    int pay;        //Pay rate
};
//Global Constants - Math/Physics Constants, Conversions,
const int SIZE=20;
//                   2-D Array Dimensions

//Function Prototypes
void menu();
void prblm2();
void prblm4a();
void prblm4b();
void prblm6();

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop and Display menu
    do{
        menu();
        cin>>choice;

        //Process/Map inputs to outputs
        switch(choice){
            case '2':{prblm2();break;}
            case '4':{prblm4a();break;}
            case '5':{prblm4b();break;}
            case '6':{prblm6();break;}
            default: cout<<"Exiting Menu"<<endl;
        }
    }while(choice>='1'&&choice<='6');
    
    //Exit stage right!
    return 0;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Menu
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void menu(){
    //Display menu
    cout<<endl<<"Choose from the following Menu"<<endl;
    cout<<"Type 2 for Problem 2"<<endl;
    cout<<"Type 4 for Problem 4a"<<endl;
    cout<<"Type 5 for Problem 4b"<<endl;
    cout<<"Type 6 for Problem 6"<<endl<<endl;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 1
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm2(){
    cout<<"Problem 2"<<endl;
    //set precision
    //cout<<setprecision(2)<<fixed<<endl;
    //Declare all Variables Here
    char ansr;
    employee emp[SIZE];
    int grss;
    unsigned short onesdig,//Ones place
                   tensdig,//Tens place
                   hunsdig,//Hundreds place
                    thsdig;//Thousands place
    string a,//Displays Thousands
           b,//Displays Hundreds
           c,//Displays Tens
           d;//Displays Ones
    cin.ignore();
    //Input or initialize values Here
    for(int i=0;i<SIZE;i++){
        cin.ignore();
        cout<<"What is your name?"<<endl;
        getline(cin,emp[i].name);
        cout<<"What is your Company's name?"<<endl;
        getline(cin,emp[i].comp);
        cout<<"What is your Company's address?"<<endl;
        getline(cin,emp[i].addss);
        cout<<"How many hours worked?"<<endl;
        cin>>emp[i].hours;
        cout<<"What is your pay rate? $/hr"<<endl;
        cin>>emp[i].pay;
        cout<<endl;
        //Check correct pay
        if (emp[i].pay <1.00){
            cout<<"Are you even on the payroll?"<<endl;
            //return 2;
        }
        //Calculate and then display
        //Straight time 1-40 hrs
        if(emp[i].hours >=1 && emp[i].hours <= 40){
            grss = emp[i].hours * emp[i].pay;
        }
        //Double Time 41 - 50 hrs
        else if(emp[i].hours >40 && emp[i].hours <=50){
            grss = (emp[i].pay * 40) + 
                    ((emp[i].hours - 40) * (emp[i].pay * 2));
        }
        //Triple Time 51+ hrs
        else if(emp[i].hours > 50){
            grss = (emp[i].pay * 40) + 
                    ((10) * (emp[i].pay * 2)) +
                    ((emp[i].hours - 50) * (emp[i].pay * 3));
        }
        //Hours is less than 1 exit.
        else{
            cout<<"Error. Why are you still working here?"<<endl;
            //return 2;
        }

        //Word value of paycheck
        thsdig  = grss /1000;
        hunsdig = grss / 100 % 10;
        tensdig = grss / 10 % 10;
        onesdig = grss % 10;

        //Calculate the 1000's, 100's, 10's and 1's
        //1000's
        switch(thsdig){
            case 1: //cout one thousand 
                a = "One Thousand ";
                break;
            case 2: //cout two thousand
                a = "Two Thousand ";
                break;
            case 3: //cout three thousand
                a = "Three Thousand ";
                break;
            default://cout blank space
                a = "";
        }
        //100's
        switch(hunsdig){
            case 1: //cout one hundred 
                b = "One Hundred ";
                break;
            case 2: //cout two hundred
                b = "Two Hundred ";
                break;
            case 3: //cout three hundred
                b = "Three Hundred ";
                break;
            case 4: //cout four hundred
                b = "Four Hundred ";
                break;
            case 5: //cout five hundred
                b = "Five Hundred ";
                break;
            case 6: //cout six hundred
                b = "Six Hundred ";
                break;
            case 7: //cout seven hundred
                b = "Seven Hundred ";
                break;
            case 8: //cout eight hundred
                b = "Eight Hundred ";
                break;
            case 9: //cout nine hundred
                b = "Nine Hundred ";
                break;
            default://cout blank space
                b = "";
        }
        //Teen's 
        if((tensdig == 1) && (onesdig >= 1)){
            switch(onesdig){
                case 1:
                    c = "Eleven ";
                    break;
                case 2:
                    c = "Twelve ";
                    break;
                case 3:
                    c = "Thirteen ";
                    break;
                case 4: 
                    c = "Fourteen ";
                    break;
                case 5: 
                    c = "Fifteen ";
                    break;
                case 6: 
                    c = "Sixteen ";
                    break;
                case 7: 
                    c = "Seventeen ";
                    break;
                case 8:
                    c = "Eighteen ";
                    break;
                case 9: 
                    c = "Nineteen ";
                    break;
            }
            cout<<a<<b<<c<<"and no/100's Dollars"<<endl;
            //return (0);
        }
        //10's place
        else if(0<= tensdig <1 || 2<= tensdig <=9){
            switch(tensdig){
            case 2: //cout twenty
                c = "Twenty ";
                break;
            case 3: //cout thirty
                c = "Thirty ";
                break;
            case 4: //cout fourty
                c = "Fourty ";
                break;
            case 5: //cout fifty
                c = "Fifty ";
                break;
            case 6: //cout sixty
                c = "Sixty ";
                break;
            case 7: //cout seventy
                c = "Seventy ";
                break;
            case 8: //cout eighty
                c = "Eighty ";
                break;
            case 9: //cout ninety
                c = "Ninety ";
                break;
            default://cout blank space
                c = "";
            }
        }
        //1's 
        switch(onesdig){
            case 1: //cout one 
                d = "One ";
                break;
            case 2: //cout two
                d = "Two ";
                break;
            case 3: //cout three
                d = "Three ";
                break;
            case 4: //cout four
                d = "Four ";
                break;
            case 5: //cout five
                d = "Five ";
                break;
            case 6: //cout six
                d = "Six ";
                break;
            case 7: //cout seven
                d = "Seven ";
                break;
            case 8: //cout eight
                d = "Eight ";
                break;
            case 9: //cout nine 
                d = "Nine ";
                break;
            default://cout blank space
                d = "";
            }

        cout<<"Company: "<<emp[i].comp<<endl;
        cout<<"Address: "<<emp[i].addss<<endl;
        cout<<"Name: "<<emp[i].name<<" ";
        cout<<"Amount: $"<<grss<<endl;             //Numerical
        cout<<"Amount: "<<a<<b<<c<<d<<"and no/100's Dollars"<<endl;             //Word Value
        cout<<"Signature Line: "<<emp[i].name<<endl;
        cout<<"Quit? (y/n)"<<endl;
        cin>>ansr;
        if(ansr='y'){
            i=SIZE;
        }
        cout<<endl;
    }
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                         Problem 2
//Input:  -> Parameters in Argument List, Description/Range/Units
//Output: -> Return, Description/Range/Units
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
void prblm4a(){
    cout<<"Problem 4a"<<endl;
    cout<<endl;
    //Declare Variables
    bool cor= false;
    unsigned short     tempa,tempb,//For swapping
                       num,//Input number 1000-7777
                   onesdig,//Ones place
                   tensdig,//Tens place
                   hunsdig,//Hundreds place
                    thsdig;//Thousands place
    //Initial Variables
    do{
        cout<<"Enter number. (0000-7777)"<<endl;
        cin>>num;
        if(num <0 || num >7777){
            cout<<"Error invalid input, please try again"<<endl;
            cor=true;
        }
    }while(cor);
    thsdig  = num /1000;
    hunsdig = num / 100 % 10;
    tensdig = num / 10 % 10;
    onesdig = num % 10;
    //Encrypting
    thsdig = (thsdig + 5) %8;
    hunsdig = (hunsdig + 5) %8;
    tensdig = (tensdig + 5) %8;
    onesdig = (onesdig + 5) %8;
    //swapping places
    tempa = thsdig;
    thsdig = tensdig;
    tensdig = tempa;
    tempb = hunsdig;
    hunsdig = onesdig;
    onesdig = tempb;
    //Map/Process Inputs to Outputs
    cout<<thsdig<<hunsdig<<tensdig<<onesdig<<endl;
}
void prblm4b(){
    cout<<"Problem 4b"<<endl;
    cout<<endl;
    //Declare Variables
    bool cor= false;
    unsigned short     tempa,tempb,//For swapping
                       num,//Input number 1000-7777
                   onesdig,//Ones place
                   tensdig,//Tens place
                   hunsdig,//Hundreds place
                    thsdig;//Thousands place
    //Initial Variables
    do{
        cout<<"Enter number. (0000-7777)"<<endl;
        cin>>num;
        if(num <0 || num >7777){
            cout<<"Error invalid input, please try again"<<endl;
            cor=true;
        }
    }while(cor);
    thsdig  = num /1000;
    hunsdig = num / 100 % 10;
    tensdig = num / 10 % 10;
    onesdig = num % 10;
    //Decrypting using switches
    switch(thsdig){
        case 0: thsdig=3;break;
        case 1: thsdig=4;break;
        case 2: thsdig=5;break;
        case 3: thsdig=6;break;
        case 4: thsdig=7;break;
        case 5: thsdig=0;break;
        case 6: thsdig=1;break;
        case 7: thsdig=2;break;
    }
    switch(hunsdig){
        case 0: hunsdig=3;break;
        case 1: hunsdig=4;break;
        case 2: hunsdig=5;break;
        case 3: hunsdig=6;break;
        case 4: hunsdig=7;break;
        case 5: hunsdig=0;break;
        case 6: hunsdig=1;break;
        case 7: hunsdig=2;break;
    }
    switch(tensdig){
        case 0: tensdig=3;break;
        case 1: tensdig=4;break;
        case 2: tensdig=5;break;
        case 3: tensdig=6;break;
        case 4: tensdig=7;break;
        case 5: tensdig=0;break;
        case 6: tensdig=1;break;
        case 7: tensdig=2;break;
    }
    switch(onesdig){
        case 0: onesdig=3;break;
        case 1: onesdig=4;break;
        case 2: onesdig=5;break;
        case 3: onesdig=6;break;
        case 4: onesdig=7;break;
        case 5: onesdig=0;break;
        case 6: onesdig=1;break;
        case 7: onesdig=2;break;
    }
    //swapping places
    tempa = thsdig;
    thsdig = tensdig;
    tensdig = tempa;
    tempb = hunsdig;
    hunsdig = onesdig;
    onesdig = tempb;
    //Map/Process Inputs to Outputs
    cout<<thsdig<<hunsdig<<tensdig<<onesdig<<endl;
}

void prblm6(){
    cout<<"Problem 6"<<endl;
    cout<<"A) 2.875"<<endl;
    cout<<"10.111(base 2), 2.7(base 8), 2.E(base 16)"<<endl;
    cout<<"A) 0.1796875"<<endl;
    cout<<"0.0010111(base 2), 0.134(base 8), 0.2E(base 16)"<<endl;
    cout<<"B) -2.875"<<endl;
    cout<<"-10.111(base 2), -2.7(base 8), -2.E(base 16)"<<endl;
    cout<<"A) 0.1796875"<<endl;
    cout<<"-0.0010111(base 2), -0.134(base 8), -0.2E(base 16)"<<endl;
    cout<<"C) 59999901, 59999902, A66667FE"<<endl;
    cout<<", , "<<endl;
    //Exit
}

