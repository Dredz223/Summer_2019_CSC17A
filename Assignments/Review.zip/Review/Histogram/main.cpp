/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on June 27th, 2019 7:57PM
 * Purpose:  Histogram
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char  thsplc,//First digit place
         hunsplc,//Second digit place
         tensplc,//Third digit place
         onesplc;//Fourth digit place
    
    //Input or initialize values Here
    cout<<"Create a histogram chart."<<endl;
    cout<<"Input 4 digits as characters."<<endl;
    cin>>thsplc;
    cin>>hunsplc;
    cin>>tensplc;
    cin>>onesplc;
   
    //Histogram Here
    //1's Place
    if(onesplc>= '0' && onesplc <='9'){
        switch(onesplc){
            case'0'://Display no star 
            cout<<"0 "<<endl;
                break;
            case'1'://display * based off the number given "1"
            cout<<"1 *"<<endl; 
                break;
            case'2'://Display ** based off the number given "2"
            cout<<"2 **"<<endl;
                break;
            case'3'://display *** based off the number given "3"
            cout<<"3 ***"<<endl; 
                break;
            case'4'://Display **** based off the number given "4"
            cout<<"4 ****"<<endl;
                break;
            case'5'://display ***** based off the number given "5"
            cout<<"5 *****"<<endl; 
                break;
            case'6'://Display ****** based off the number given "6"
            cout<<"6 ******"<<endl;
                break;
            case'7'://display ******* based off the number given "7"
            cout<<"7 *******"<<endl; 
                break;
            case'8'://Display ******** based off the number given "8"
            cout<<"8 ********"<<endl;
                break;
            case'9'://Display ********* based off the number given "9"
            cout<<"9 *********"<<endl;
                break;
        }
    }
    else{
        //Display ? for letters
        cout<<onesplc<<" ?"<<endl;
    }
    
    //10's Place
    if(tensplc>= '0' && tensplc <='9'){
    switch(tensplc){
            case'0'://Display no star 
            cout<<"0 "<<endl;
                break;
            case'1'://display * based off the number given "1"
            cout<<"1 *"<<endl; 
                break;
            case'2'://Display ** based off the number given "2"
            cout<<"2 **"<<endl;
                break;
            case'3'://display *** based off the number given "3"
            cout<<"3 ***"<<endl; 
                break;
            case'4'://Display **** based off the number given "4"
            cout<<"4 ****"<<endl;
                break;
            case'5'://display ***** based off the number given "5"
            cout<<"5 *****"<<endl; 
                break;
            case'6'://Display ****** based off the number given "6"
            cout<<"6 ******"<<endl;
                break;
            case'7'://display ******* based off the number given "7"
            cout<<"7 *******"<<endl; 
                break;
            case'8'://Display ******** based off the number given "8"
            cout<<"8 ********"<<endl;
                break;
            case'9'://Display ********* based off the number given "9"
            cout<<"9 *********"<<endl;
                break;
        }
    }
    else{
        //Display ? for letters
        cout<<tensplc<<" ?"<<endl;
    }
    
    //100's  Place
    if(hunsplc >= '0' && hunsplc <='9'){
        switch(hunsplc){
            case'0'://Display no star 
            cout<<"0 "<<endl;
                break;
            case'1'://display * based off the number given "1"
            cout<<"1 *"<<endl; 
                break;
            case'2'://Display ** based off the number given "2"
            cout<<"2 **"<<endl;
                break;
            case'3'://display *** based off the number given "3"
            cout<<"3 ***"<<endl; 
                break;
            case'4'://Display **** based off the number given "4"
            cout<<"4 ****"<<endl;
                break;
            case'5'://display ***** based off the number given "5"
            cout<<"5 *****"<<endl; 
                break;
            case'6'://Display ****** based off the number given "6"
            cout<<"6 ******"<<endl;
                break;
            case'7'://display ******* based off the number given "7"
            cout<<"7 *******"<<endl; 
                break;
            case'8'://Display ******** based off the number given "8"
            cout<<"8 ********"<<endl;
                break;
            case'9'://Display ********* based off the number given "9"
            cout<<"9 *********"<<endl;
                break;
        }
    }
    else{
        //Display ? for anything else that isn't a number
            cout<<hunsplc<<" ?"<<endl;
    }
    
    //1000's place
    if(thsplc >= '0' && thsplc <='9'){
        switch(thsplc){
            case'0'://Display no star 
            cout<<"0 "<<endl;
                break;
            case'1'://display * based off the number given "1"
            cout<<"1 *"<<endl; 
                break;
            case'2'://Display ** based off the number given "2"
            cout<<"2 **"<<endl;
                break;
            case'3'://display *** based off the number given "3"
            cout<<"3 ***"<<endl; 
                break;
            case'4'://Display **** based off the number given "4"
            cout<<"4 ****"<<endl;
                break;
            case'5'://display ***** based off the number given "5"
            cout<<"5 *****"<<endl; 
                break;
            case'6'://Display ****** based off the number given "6"
            cout<<"6 ******"<<endl;
                break;
            case'7'://display ******* based off the number given "7"
            cout<<"7 *******"<<endl; 
                break;
            case'8'://Display ******** based off the number given "8"
            cout<<"8 ********"<<endl;
                break;
            case'9'://Display ********* based off the number given "9"
            cout<<"9 *********"<<endl;
                break;
        }
    }
    else {
        //Display ? for anything else that isn't a number
        cout<<thsplc<<" ?"<<endl;
    }
    
    //Exit
    return 0;
}