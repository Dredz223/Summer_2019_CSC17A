/*
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on June 27th, 2019 8:18 PM
 * Purpose:  Summing, Finding the Max and Min of an integer array
 * Note:  Look at the output for the format for print
 */

// System Libraries Here
#include <iostream> //cin,cout
using namespace std;

// User Libraries Here

// Global Constants Only, No Global Variables

// Function Prototypes Here
void read(int[], int);
int stat(const int[], int, int &, int &);
void print(const int[], int, int, int, int);
void sorting(int[], int);

// Program Execution Begins Here
int main(int argc, char **argv) {
  // Declare all Variables Here
  int sizeIn, sum, min, max;
  
  // Input the size of the array you are sorting
  cout << "Read in a 1 dimensional array of integers find sum/min/max" << endl;
  cout << "Input the array size where size <= 20" << endl;
  cin >> sizeIn;
  
  int array[sizeIn];
  
  // Now read in the array of integers
  cout << "Now read the Array" << endl;
  read(array, sizeIn); // Read in the array of integers
  sorting(array, sizeIn);
  
  // Find the sum, max, and min
  sum = stat(array, sizeIn, max, min); // Output the sum, max and min
  
  // Print the results
  print(array, sizeIn, sum, max, min); // print the array, sum, max and min
  
  // Exit
  return 0;
}

void read(int a[], int n) {
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
}

int stat(const int a[], int n, int &max, int &min) {
  int sum = 0;
  min = a[0];
  max = a[n - 1];
  for (int i = 0; i < n; i++) {
    sum += a[i];
  }
  return sum;
}

void print(const int a[], int n, int s, int max, int min) {
  for (int i = 0; i < n; i++) {
    cout<<"a["<<i<<"] = "<<a[i]<<endl;
  }
  cout <<"Min  = " << min << endl;
  cout <<"Max  = " << max << endl;
  cout <<"Sum  = " << s << endl;
}

void sorting(int A[], int n) {
  // This is a bubble sort
  // Keep looping and comparing until no swaps are left
  bool swap;
  do {
    swap = false;
    // Check the list and Swap when necessary
    for (int i = 0; i < n - 1; i++) {
      if (A[i] > A[i + 1]) {
        int temp = A[i];
        A[i] = A[i + 1];
        A[i + 1] = temp;
        swap = true;
      }
    }
  } while (swap);
}