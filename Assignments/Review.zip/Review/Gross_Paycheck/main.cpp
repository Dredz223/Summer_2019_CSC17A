/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on June 27th, 2019 8:04PM
 * Purpose:  Gross Paycheck
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float payRate,payChk;
    unsigned short hrsWrkd;
    
    std::cout << std::fixed;
    std::cout << setprecision(2);
    
    //Input or initialize values Here
    cout<<"Paycheck Calculation."<<endl;
    cout<<"Input payRate in $'s/hour and hours worked"<<endl;
    cin>>payRate>>hrsWrkd;
    
    //Calculate Paycheck
    //straight time 1-20 hrs
    if(hrsWrkd <=20){
        payChk = payRate * hrsWrkd;
    }
    //Time and a half 21-40 hrs
    else if(hrsWrkd >20 && hrsWrkd <=40){
        payChk = (payRate *20) + (payRate * 1.5) * (hrsWrkd - 20);
    }
    //double pay 40hrs++
    else{
        payChk = (payRate * 20) + (payRate * 1.5) *(20) + 
                 (payRate *2) * (hrsWrkd - 40);
    }
    //Output the check
    cout<<"$"<<payChk<<endl;
    
    //Exit
    return 0;
}