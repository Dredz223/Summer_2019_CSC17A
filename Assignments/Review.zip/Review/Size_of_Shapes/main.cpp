/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on June 27th, 2019 7:50 PM
 * Purpose:  Size of Shapes
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned short  x;
    char    shape;       //f-> forward b->backward x->cross
    float   remain;
    
    //Input or initialize values Here
    cout<<"Create a numbered shape that can be sized."<<endl;
    cout<<"Input an integer number [1,50] and a character [x,b,f]."<<endl;
    cin>>x>>shape;
    
    remain=x%2;

    //Draw the shape
    //Even Numbers
    if (remain == 0){
        if (shape == 'x'){
            for(int row=1, i=x; row <=x; row++, i--){
                for(int colmn=1, y=1; colmn <=x; colmn++, y++){
                    if(row==colmn){
                        cout<<y;
                    }
                    else if (colmn== (x+1) - row){
                        cout<<i;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
        else if (shape == 'b'){
            for(int row=1, i=1; row <=x; row++, i++){
                for(int colmn=1; colmn <=x; colmn++){
                    if(row==colmn){
                        cout<<i;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
        else{
            for(int row=1, i=x; row <=x; row++, i--){
                for(int colmn=1; colmn <=x; colmn++){
                    if(colmn== (x+1) - row){
                        cout<<i;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
    }
    
    
    //Odd numbers
    else{
        if (shape == 'x'){
            for(int row=1, i=x, y=1; row <=x; row++, i--, y++){
                for(int colmn=1; colmn <=x; colmn++){
                    if(row==colmn){
                        cout<<i;
                    }
                    else if (colmn== (x+1) - row){
                        cout<<y;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
        else if (shape == 'b'){
            for(int row=1, i=x; row <=x; row++, i--){
                for(int colmn=1; colmn <=x; colmn++){
                    if(row==colmn){
                        cout<<i;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
        else{
            for(int row=1, i=1; row <=x; row++, i++){
                for(int colmn=1; colmn <=x; colmn++){
                    if(colmn== (x+1) - row){
                        cout<<i;
                    }
                    else{
                        cout<<" ";
                    }
                }
                cout<<endl;
            }
        }
    }
    
    //Exit
    return 0;
}