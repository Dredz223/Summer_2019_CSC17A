/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on June 27th 2019, 9:00PM
 * Purpose:  Sum Rows, Sum Columns, Grand Sum of an integer array
 */

//System Libraries Here
#include <iostream>//cin,cout
#include <iomanip> //setw(10)
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Allowed like PI, e, Gravity, conversions, array dimensions necessary
const int COLMAX=80;  //Max Columns much larger than needed.

//Function Prototypes Here
void read(int [][COLMAX],int &,int &);//Prompt for size then table

void print(int [][COLMAX],int,int,int);//Either table can be printed

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const int ROW=80;           //Max Rows much larger than needed
    int a[ROW][COLMAX]={};  //Declare original array
    int r,c;                
    
    //Input the original table
    read(a,r,c);
    
    //Augment the original table by the sums
    int aug[r+1][c+1]={};
    int grd=0;
    for(int i=0; i<r+1; i++){
        for(int j=0; j<c+1; j++){
            aug[i][j] = 0;
        }
    }
    //columns
    for(int j=0; j<c; j++){
        int sum = 0;
        for(int i=0; i<r; i++){
            sum+=a[i][j];
            aug[r][j]+=a[i][j];
        }
        grd+=sum;
    }
    aug[r][c]=grd;
    //rows
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            aug[i][c]+=a[i][j];
        }
    }
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            aug[i][j]=a[i][j];
        }
    }
    
    //Output the original array
    cout<<endl<<"The Original Array"<<endl;
    print(a,r,c,10);//setw(10)
    
    //Output the augmented array
    cout<<endl<<"The Augmented Array"<<endl;
    for(int i=0; i<r+1;i++){
        for(int j=0; j<c+1; j++){
            cout<<setw(10);
            cout<<aug[i][j];
        }
        cout<<endl;
    }
    
    //Exit
    return 0;
}
void read(int a[][COLMAX],int &row,int &col){
    cout<<"Input a table and output the Augment row,col and total sums."<<endl;
    cout<<"First input the number of rows and cols. <20 for each"<<endl;
    cout<<"Now input the table."<<endl;
    cin>>row>>col;
    for(int i=0; i<row; i++){
        for(int j=0; j<col; j++){
            cin>>a[i][j];
        }
    }
}

void print(int a[][COLMAX],int row ,int col,int s){
    for(int i=0; i<row; i++){
        for(int j=0; j<col; j++){
            cout<<setw(s);
            cout<<a[i][j];
        }
        cout<<endl;
    }
}
