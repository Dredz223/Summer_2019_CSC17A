/* 
 * File:   main.cpp
 * Author: Andres Guerrero Maldonado
 * Created on July 9, 2018, 2:26 PM
 * Purpose:  Gross Paycheck, with structures. Midterm Q2
 */

//System Libraries Here
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries Here
struct employee{
    string name;
    int hours;
    int pay;
};
//Global Constants Only, No Global Variables
const int SIZE = 80;
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    employee emp[SIZE];
    
    //Input or initialize values Here
    for(int i=0;i<SIZE;i++){
        cout<<"What is your name?"<<endl;
        getline(cin,emp[i].name);
        cout<<"How many hours worked?"<<endl;
        cin>>emp[i].hours;
        cout<<"What is your pay rate? $/hr"<<endl;
        cin>>emp[i].pay;
        cout<<endl;
        
        cout<<"Company"<<endl;
        cout<<"Address"<<endl;
        cout<<"Name: "<<emp[i].name<<" ";
        cout<<"Amount: $"<<endl;             //Numerical
        cout<<"Amount: "<<endl;             //Word Value
        cout<<"Signature Line: "<<endl;
        cout<<emp[i].hours<<" ";
        cout<<emp[i].pay<<" "<<endl;
        cout<<endl;
    }
    //Process/Calculations Here
    
    //Output Located Here
    
    
    //Exit
    return 0;
}

